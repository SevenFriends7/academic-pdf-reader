# 学术文献双栏翻译阅读器 (Academic Literature Reader)

专为学术论文研读设计的 VS Code / 反重力 IDE (Antigravity IDE) 扩展插件：**左栏文献原文、右栏译文对照、鼠标划词实时双向高光联动、划线高亮与便签批注、一键导出 Markdown 笔记**。

---

## ✨ 核心特性

### 1. 📖 双栏文献对照阅读
- **左栏**：基于 PDF.js 完整渲染原版 PDF 文献，支持缩放（放大、缩小、适合宽度）、跳转翻页、高保真文字层（Text Layer）。
- **右栏**：支持【逐句精读】与【连贯段落】双模式自由切换，智能段落重组器（自动修复跨行断词与连字符，如 `differ- \n ent` 拼合），告别机械机翻的碎片感。
- **自由分栏**：中间配备可拖拽的 Splitter 分割条，随心调整左右视窗比例。

### 2. ⚡ 鼠标划词双向高光联动
- **左选右亮**：在左侧 PDF 中使用鼠标选中任意单词或句子，右侧对应的段落翻译卡片立即触发**发光呼吸灯高亮（Glow Highlight）**，并自动平滑滚动至视野正中，快速定位理解。
- **右点左闪**：点击右侧翻译卡片的“定位”按钮或段落本身，左侧 PDF 自动平滑滚动到该段落所在页面与位置，并以动态微光高亮闪烁，实现完美的双向视觉对齐。

### 3. ✍️ 划线高亮与便签批注
- **划词悬浮菜单 (Floating Action Bar)**：选中文字瞬间浮出 Notion 风格的工具条：
  - **4 色荧光笔高亮**：🟨 核心要点 / 🟩 论据数据 / 🟦 公式方法 / 🟥 疑难待查。
  - **添加批注便签**：记录个人理解、推导公式、文献对比心得。
  - **即时查词/译句**：无需切换页面，悬浮气泡即时展现当前短语的精准译文。
- **批注库管理**：右上角切换【批注笔记】视图，所有批注按页码聚合，支持点击一键跳转原文、修改、删除。
- **自动持久化**：所有批注与翻译缓存均自动保存在本地，下次打开同一篇文献无需重复翻译，所有标记与批注永久保留。

### 4. 📝 一键导出 Markdown 研读笔记
- 点击顶部【导出笔记】，自动生成结构化、美观的 Markdown 笔记文件（含原文字句、对照翻译、页码、高亮分类、个人批注与思考），无缝导入 **Obsidian**、**Notion** 或个人知识库。

### 5. 🌐 灵活强大的翻译引擎
- **Google Gemini 官方 API（强烈推荐）**：专为学术论文研读调优的学术 Prompt，术语地道严谨，公式与引用规范完整保留，Google AI Studio 提供充裕免费额度。
- **自定义大模型 (DeepSeek / OpenAI / Kimi 等)**：兼容 OpenAI 标准接口，国内直连、性价比极高。
- **开箱即用 (内置免费翻译)**：无需申请任何 API Key，安装即可直接使用基础翻译。

---

## 📦 如何分享与安装插件

将生成的 `academic-pdf-reader-0.1.0.vsix` 文件直接发送给他人，接收者通过以下简易步骤即可安装：

### 在反重力 IDE (Antigravity IDE) 中安装
1. 打开反重力 IDE。
2. 点击左侧活动栏的 **扩展市场** 图标（或按快捷键 `Ctrl+Shift+X`）。
3. 点击扩展视图右上角的 **`...` (更多操作)** 菜单。
4. 选择 **“从 VSIX 安装... (Install from VSIX...)”**。
5. 选中接收到的 `academic-pdf-reader-0.1.0.vsix` 文件，即可安装完成！
> 也可以在命令行终端直接执行：
> ```bash
> antigravity-ide.cmd --install-extension academic-pdf-reader-0.1.0.vsix
> ```

### 在 VS Code 中安装
1. 打开 VS Code。
2. 按快捷键 `Ctrl+Shift+X` 打开扩展面板。
3. 点击右上角 `...` 菜单 -> 选择 **“从 VSIX 安装... (Install from VSIX...)”**。
4. 选中 `academic-pdf-reader-0.1.0.vsix` 完成安装。

---

## 🔑 如何配置自己的 API Key

安装完成后，打开任意 PDF 文献，有以下 3 种方式配置个人 API Key：

### 方式一：在文献阅读界面点击【⚙️ 设置】（最推荐、最直观）
1. 在双栏阅读器右上角顶部工具栏，直接点击 **`⚙️ 设置`** 按钮。
2. 屏幕上方会弹出交互式快捷菜单：
   - **`🔑 配置 Google Gemini API Key (推荐)`**：点击后直接粘贴你的 Gemini Key，保存即生效；
   - **`🤖 配置自定义大模型 (DeepSeek / OpenAI / Kimi)`**：逐步输入 API Key、Base URL 与模型名称；
   - **`🌐 切换为内置免费翻译引擎`**：无需任何 Key，直接联网翻译；
   - **`⚙️ 打开完整插件设置页面`**：进入可视化图形设置面板。

### 方式二：通过快捷指令配置 (Command Palette)
1. 按下快捷键 `Ctrl+Shift+P`（或 `F1`）。
2. 输入 **`文献阅读`**，选择：
   - **`文献阅读：配置翻译引擎与 API Key`**（打开设置向导）；
   - 或 **`文献阅读：设置 Google Gemini API Key`**（直接填入 Key）。

### 方式三：在 IDE 设置中心自定义 (Settings GUI)
按下 `Ctrl+,` 打开设置，搜索 **`academicReader`**，即可按需修改全部配置项：

| 配置项 | 默认值 | 说明 |
| :--- | :--- | :--- |
| `academicReader.translationService` | `gemini` | 翻译引擎选择：`gemini` (官方 API，推荐) / `openai-compatible` (自定义大模型) / `built-in` (免费免 Key) |
| `academicReader.geminiApiKey` | `""` | 你的 Google Gemini API Key |
| `academicReader.geminiModel` | `gemini-2.0-flash` | Gemini 模型选择 (`gemini-2.0-flash`, `gemini-1.5-flash`, `gemini-1.5-pro`) |
| `academicReader.apiEndpoint` | `https://api.deepseek.com/v1` | 自定义大模型 Base URL（如 DeepSeek、Kimi、OpenAI 端点） |
| `academicReader.apiKey` | `""` | 自定义大模型 API 密钥 |
| `academicReader.modelName` | `deepseek-chat` | 自定义大模型名称（如 `deepseek-chat`, `gpt-4o-mini`） |
| `academicReader.targetLanguage` | `zh-CN` | 目标翻译语言（简体中文、繁体中文、英文、日语等） |
| `academicReader.autoTranslate` | `true` | 翻页时是否自动预解析并翻译当前页段落 |

---

## 💡 常用 API Key 获取与推荐

### 1. 免费申请 Google Gemini API Key（30 秒获取）
1. 访问 [Google AI Studio](https://aistudio.google.com/app/apikey)；
2. 登录 Google 账号，点击 **"Create API key"**；
3. 复制生成的以 `AIzaSy...` 开头的密钥；
4. 在阅读器顶部点击【设置】->【配置 Google Gemini API Key】粘贴即可！
> Google AI Studio 拥有充裕的免费并发额度，学术论文翻译质量极高，推荐作为第一选择。

### 2. 国内用户推荐配置 DeepSeek
1. 访问 [DeepSeek 开放平台](https://platform.deepseek.com/) 注册并获取 API Key；
2. 在阅读器顶部点击【设置】->【配置自定义大模型】：
   - API Key: `sk-xxxxxxxxxxxxxxxx`
   - API 端点: `https://api.deepseek.com/v1`
   - 模型名称: `deepseek-chat`
> DeepSeek 的学术翻译自然通顺，计费极低，非常适合国内科研人员。

---

## 🛠️ 开发者本地构建

```bash
# 1. 安装依赖
npm install

# 2. 编译代码
npm run compile

# 3. 一键打包并安装为 .vsix
npm run package
```
